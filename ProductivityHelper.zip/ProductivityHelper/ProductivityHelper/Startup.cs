﻿using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProductivityHelper
{
    public class Startup : FunctionsStartup
    {
        //use for depencency injection eventually for config values etc
        public override void Configure(IFunctionsHostBuilder builder)
        {
           // throw new NotImplementedException();
        }
    }
}
