using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Text;
using System.Collections.Generic;
using Azure.Identity;

namespace ProductivityHelper
{
    //Calls Microsoft Graph Api 
    public static class MicrosoftService
    {
        [FunctionName("MicrosoftService")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");
            //Gets Bearer Token from Microsoft Login API
            var httpClient = new HttpClient();
            var result = new HttpResponseMessage();

            //all following needed for MS login API 
            // GET THESE SECRET VALUES FROM CONFIG DO NOT PUT IN CODE DIRECTLY
            var scope = new[] { "https://graph.microsoft.com/.default" };
            var clientId = ""; //use ITRS's azure app registration clientid
            var clientSecret = ""; //use ITRS's azure app registration clientsecret
            var tenantId = ""; //ITRS tenant id
            var options = new TokenCredentialOptions
            {
                AuthorityHost = AzureAuthorityHosts.AzurePublicCloud
            };
            // calling microsoft login api by setting it as the address and providing it with client ID and secret using graph api sdk
            var clientSecretCredential = new ClientSecretCredential(
                tenantId, clientId, clientSecret, options);
            //getting Authorization bearer token
            var accessToken = await clientSecretCredential.GetTokenAsync(new Azure.Core.TokenRequestContext(scope) { });
           
            if (accessToken.Token != null) //making sure above call was successful
            {
          
                using (httpClient) //resusing httpclient variable with different API endpoint to call microsoft graph API
                {
                    //for this example we are using a get to all apps for the MS Teams application but other endpoints are found here: https://www.postman.com/microsoftgraph/workspace/microsoft-graph/
                    httpClient.BaseAddress = new Uri("https://graph.microsoft.com/v1.0/teams/a3b91190-ed92-45ab-9a23-75d30474f3dc/installedApps?$expand=teamsAppDefinition");
                    httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {accessToken.Token}"); //adding Authorization bearer header with token we got earlier

                    result = await httpClient.GetAsync("/api/"); //get request to call api TODO: add whatever graph api endpoint we need for ITRS
                }
            }
            return new OkObjectResult(result);
        }
    }
}
